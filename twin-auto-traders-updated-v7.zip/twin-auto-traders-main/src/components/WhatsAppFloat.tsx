const WhatsAppFloat = () => {
  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Pulse Ring */}
      <div className="absolute inset-0 rounded-full bg-green-500 animate-ping opacity-30"></div>

      {/* Main Button */}
      <a
        href="https://wa.me/94740505718?text=Hello%20Twin%20Auto%20Traders!%20I%20need%20help%20finding%20a%20part."
        target="_blank"
        rel="noopener noreferrer"
        className="relative w-14 h-14 bg-[hsl(142,70%,45%)] rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-all duration-300"
        aria-label="Chat on WhatsApp"
      >
        <svg viewBox="0 0 32 32" className="w-8 h-8 fill-white">
          <path d="M16 0C7.163 0 0 7.163 0 16c0 2.833.737 5.494 2.027 7.807L0 32l8.418-2.006A15.93 15.93 0 0 0 16 32c8.837 0 16-7.163 16-16S24.837 0 16 0zm8.279 22.098c-.344.966-2.01 1.847-2.756 1.962-.745.115-1.686.163-2.72-.17-.627-.2-1.432-.467-2.456-.913-4.317-1.865-7.137-6.23-7.354-6.52-.217-.29-1.77-2.355-1.77-4.49 0-2.134 1.12-3.186 1.518-3.623.397-.436.866-.545 1.155-.545.289 0 .578.003.831.015.266.013.623-.1.975.744.362.866 1.23 2.999 1.338 3.216.108.217.18.47.036.76-.145.29-.217.47-.434.724-.217.253-.456.565-.65.758-.217.212-.444.441-.19.866.253.424 1.12 1.847 2.406 2.993 1.654 1.475 3.05 1.932 3.474 2.15.424.216.672.18.92-.108.253-.289 1.083-1.265 1.372-1.699.289-.434.578-.362.975-.217.397.145 2.52 1.19 2.952 1.406.434.217.724.326.831.505.108.18.108 1.047-.236 2.012z" />
        </svg>
      </a>
    </div>
  );
};

export default WhatsAppFloat;